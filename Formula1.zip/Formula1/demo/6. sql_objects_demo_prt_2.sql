-- Databricks notebook source
-- MAGIC %md
-- MAGIC
-- MAGIC # creating a External Table with Python and SQL

-- COMMAND ----------

-- MAGIC %run "../includes/configuration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC race_results_df = spark.read.parquet(f"{presentation_folder_path}/race_results")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.mode("overwrite").format("parquet").option("path",f"{presentation_folder_path}/race_results_ext_py").saveAsTable("demo.results_ext_py")

-- COMMAND ----------

desc extended demo.results_ext_py

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###using SQL

-- COMMAND ----------

create table demo.race_results_ext_sql
(race_year INT,
race_name string,
race_date string,
circuit_location string,
driver_name string,
driver_number string,
driver_nationality string,
team string,
grid string,
fastest_lap string,
race_time string,
points string,
position int,
created_date timestamp
)
using parquet
location "/mnt/formula1dl712/presentation/race_results_ext_sql"

-- COMMAND ----------

show tables in demo

-- COMMAND ----------

drop table demo.race_results_ext_sql

-- COMMAND ----------

insert into demo.race_results_ext_sql
select * from demo.results_ext_py
where race_year = 2020

-- COMMAND ----------

drop table demo.race_results_ext_sql

-- COMMAND ----------

