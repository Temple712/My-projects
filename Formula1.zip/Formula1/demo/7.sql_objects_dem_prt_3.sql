-- Databricks notebook source
-- MAGIC %md
-- MAGIC
-- MAGIC # Views on Tables
-- MAGIC 1. create Temp view
-- MAGIC 2. create Global Temp view
-- MAGIC 3. create Permanent View

-- COMMAND ----------

-- MAGIC %run "../includes/configuration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC race_results_df = spark.read.parquet(f"{presentation_folder_path}/race_results")

-- COMMAND ----------

create or Replace temp view v_race_results
as
select * from demo.results_python
where race_year = 2018

-- COMMAND ----------

select * from v_race_results

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Global Temp view 

-- COMMAND ----------

create or Replace Global temp view gv_race_results
as
select * from demo.results_python
where race_year = 2012

-- COMMAND ----------

select * from global_temp.gv_race_results

-- COMMAND ----------

show tables in global_temp

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###### Permanent view

-- COMMAND ----------

create or Replace view demo.pv_race_results
as
select * from demo.results_python
where race_year = 2000

-- COMMAND ----------

show tables in demo

-- COMMAND ----------

