-- Databricks notebook source
show databases

-- COMMAND ----------

use f1_processed

-- COMMAND ----------

show tables 

-- COMMAND ----------

select * , split(name, ' ')[0] forname, split(name, ' ')[1] surname
from drivers

-- COMMAND ----------

select nationality, name, dob, rank() over (partition by nationality order by dob desc) as age_rank
from drivers
order by nationality, age_rank

-- COMMAND ----------

