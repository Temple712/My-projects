# Databricks notebook source
# MAGIC %md
# MAGIC #### Mount Azure Data Lake using Service principle
# MAGIC 1. Get client_id and client_secret from key vault
# MAGIC 2. Set Spark Config with App/Client id, Directiory/ Tenant id & Secret
# MAGIC 3. Call file system utility mount to mount the storage
# MAGIC 4. AExplore other file system utilities related to mount (list all mounts, unmount)
# MAGIC

# COMMAND ----------

client_id = dbutils.secrets.get(scope='formula1-scope', key='formula1-client')
tenant_id = dbutils.secrets.get(scope='formula1-scope', key='formula1-app-tenant-ID')
client_secret = dbutils.secrets.get(scope='formula1-scope', key='formual1-app-client-secret')

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": client_id,
          "fs.azure.account.oauth2.client.secret": client_secret,
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"}


# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://demo@formula1dl712.dfs.core.windows.net/",
  mount_point = "/mnt/formula1dl712/demo",
  extra_configs = configs)


# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dl712/demo"))

# COMMAND ----------

display(spark.read.csv("dbfs:/mnt/formula1dl712/demo/circuits.csv"))

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

dbutils.fs.unmount('/mnt/formula1dl712/demo')

# COMMAND ----------

