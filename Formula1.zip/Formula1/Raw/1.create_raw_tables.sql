-- Databricks notebook source
create database if not exists f1_raw

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### create circuits table

-- COMMAND ----------

drop table if exists f1_raw_circuits;
create table if not exists f1_raw_circuits(
  circuitId int,
  circuitRef string,
  name string,
  location string,
  country string,
  lat double,
  lng double,
  alt int,
  url string
)
using csv
options(path "/mnt/formula1dl712/raw/circuits.csv", header True)

-- COMMAND ----------

select * from f1_raw_circuits

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### create races table

-- COMMAND ----------

drop table if exists f1_raw_races;

create table if not exists f1_raw_races(
    raceId Int,
    year Int,
    round Int,
    circuitId Int,
    name String,
    date date,
    time String,
    url string
)
    using csv
  options(path "/mnt/formula1dl712/raw/races.csv", header true)


-- COMMAND ----------

select * from f1_raw_races

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## create tables for JSON files

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### create constructors table
-- MAGIC ##### . Single Line JSON
-- MAGIC ##### . Simple Structure

-- COMMAND ----------

drop table if exists f1_raw_constructors;

create table if not exists f1_raw_constructors(
 constructorId INT, 
 constructorRef STRING, 
 name STRING, 
 nationality STRING, 
 url STRING
)
    using JSON
  options(path "/mnt/formula1dl712/raw/constructors.json", header true)

-- COMMAND ----------

select* from f1_raw_constructors

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### create drivers table
-- MAGIC ##### . Single Line JSON
-- MAGIC ##### . Complex Structure

-- COMMAND ----------

drop table if exists f1_raw_drivers;

create table if not exists f1_raw_drivers(
 driverId INT, 
 driverRef STRING, 
 number STRING, 
 code STRING,
 name struct<forename: string, surname: string >,
 dob DATE,
 nationality string,
 url string
)
using JSON
options(path "/mnt/formula1dl712/raw/drivers.json", header true)

-- COMMAND ----------

select* from f1_raw_drivers

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### create results table
-- MAGIC ##### . Single Line JSON
-- MAGIC ##### . Simple Structure

-- COMMAND ----------

drop table if exists f1_raw_results;

create table if not exists f1_raw_results(
constructorId Int,
driverId Int,
fastestLap Int,
fastestLapSpeed String,
fastestLapTime String,
grid Int,
laps Int,
milliseconds Int,
number Int,
points Float,
position Int,
positionOrder int,
positionText String,
raceId Int,
time String,
rank Int,
statusId Int,
resultId Int
)
using JSON
options(path "/mnt/formula1dl712/raw/results.json", header true)

-- COMMAND ----------

select * from f1_raw_results

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### create pit_stops table
-- MAGIC ##### . Single Line JSON
-- MAGIC ##### . Simple Structure

-- COMMAND ----------

drop table if exists f1_raw_pit_stops;
create table if not exists f1_raw_pit_stops(
raceId Int,
driverId Int,
stop String,
lap Int,
duration String,
milliseconds int
)
using JSON
options(path "/mnt/formula1dl712/raw/pit_stops.json", multiLine true, header true)

-- COMMAND ----------

select * from f1_raw_pit_stops

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Create tables for list of files

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### create Lap times Table
-- MAGIC ##### . CSV file
-- MAGIC #####  . multiple files

-- COMMAND ----------

drop table if exists f1_raw_lap_times;
create table if not exists f1_raw_lap_times(
raceId Int,
driverId Int,
position Int,
milliseconds Int,
time String
)
using csv
options(path "/mnt/formula1dl712/raw/lap_times")

-- COMMAND ----------

select count(*) from f1_raw_lap_times

-- COMMAND ----------

select * from f1_raw_lap_times

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### create Qualifying Table
-- MAGIC ##### . JSON file
-- MAGIC #####  . multiple files

-- COMMAND ----------

drop table if exists f1_raw_qualifying;
create table if not exists f1_raw_qualifying(
raceId Int,
driverId Int,
position Int,
constructorId Int,
number Int,
q1 String,
q2 String,
q3 String,
qualifyId Int
)
using json
options(path "/mnt/formula1dl712/raw/qualifying", multiLine true)

-- COMMAND ----------

select * from f1_raw_qualifying

-- COMMAND ----------

