-- Databricks notebook source
-- MAGIC %md
-- MAGIC
-- MAGIC # creating a Managed Table with Python and SQL

-- COMMAND ----------

create database demo;

-- COMMAND ----------

create database if not exists demo;

-- COMMAND ----------

show databases

-- COMMAND ----------

describe database extended demo;

-- COMMAND ----------

select current_database()

-- COMMAND ----------

use demo

-- COMMAND ----------

select current_database()

-- COMMAND ----------

show tables

-- COMMAND ----------



-- COMMAND ----------

-- MAGIC %run "../includes/configuration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC race_results_df = spark.read.parquet(f"{presentation_folder_path}/race_results")

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### create a Managed Table Using Python

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").saveAsTable("demo.results_python")

-- COMMAND ----------

show tables

-- COMMAND ----------

select * from demo.results_python

-- COMMAND ----------

select driver_nationality, sum(points) as total_points from results_python
where race_year in (2019, 2020)
group by driver_nationality select driver_nationality, sum(points) as total_points from results_python
where race_year in (2019, 2020)select driver_nationality, sum(points) as total_points from results_python
where race_year in (2019, 2020)
having total_points > 500
order by total_points

-- COMMAND ----------

desc extended results_python

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### create a managed Table using SQL

-- COMMAND ----------

create table demo.results_sql
as
select * from results_python
where race_year = 2020

-- COMMAND ----------

select * from  results_sql

-- COMMAND ----------

desc extended results_sql

-- COMMAND ----------

drop table results_sql

-- COMMAND ----------

show tables

-- COMMAND ----------

